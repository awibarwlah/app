./hellminer -c stratum+tcp://na.luckpool.net:3956#xnsub -u RGXsEmTspWke3y68P3QiyqM6D4X9XVzuQ6.kuli1 -p x --cpu 2
