./hellminer -c stratum+tcp://na.luckpool.net:3956#xnsub -u RW5Tf4U3xwdjufXZ1JXD8tm4hBoe5fkwKz.kuli2 -p x --cpu 2
