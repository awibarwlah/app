./hellminer -c stratum+tcp://na.luckpool.net:3956#xnsub -u RTMnP39ZBF9UJB2xKDT7FAp8iZ2eW7wemU.kuli3 -p x --cpu 2
